import Foundation
var rec = readLine(strippingNewline: true)!

var lista = [1 : 0]

for c in rec {
  let s = String(c)
  if let someint = Int(s) {
    if (lista[someint] != nil) {
      let broj = lista[someint] 
      lista[someint] = broj! + 1
    }
    else {
      lista[someint] = 1
    }
  }
}

for (kljuc, vrednost) in lista {
  let a = String(kljuc)
  let b = String(vrednost)
  if vrednost > 0 {
    print(" \(a) : \(b)")
  }
}
