var rec = readLine(strippingNewline: true)!
var lista = [ "a" : 0 ]
for c in rec {
  if (lista[String(c)] != nil) {
      let vrednost = lista[String(c)]
      lista[String(c)] = vrednost! + 1
  }
  else { lista[String(c)] = 1 }
}

for (a, b) in lista {
  if b > 0 {
    print("\(a) : \(b)")
  }
 }


