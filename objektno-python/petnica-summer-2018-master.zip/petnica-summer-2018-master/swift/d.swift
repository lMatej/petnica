import Foundation

struct Jedi : Decodable {
    var name: String
    var height: String
    var mass: String
    var hair_color: String
    var skin_color: String
    var eye_color: String
    var birth_year: String
    var gender: String
}

let json = """
{
    "name": "Luke Skywalker",
    "height": "172",
    "mass": "77",
    "hair_color": "blond",
    "skin_color": "fair",
    "eye_color": "blue",
    "birth_year": "19BBY",
    "gender": "male",
}

""".data(using: .utf8)!

let jsonData = json
let decoder = JSONDecoder()
let jedi = try! decoder.decode(Jedi.self, from: jsonData)

print(jedi.name)