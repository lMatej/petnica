import pandas as pd

Porudzbine = pd.read_csv("files/orders.csv")

print(Porudzbine)
