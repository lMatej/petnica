import numpy as np
import matplotlib.pyplot as plt

a = np.array(list(range(-30, 30))) * 0.1 * np.pi * 2
b = np.sin(a)
plt.plot(a, b)
plt.show()
