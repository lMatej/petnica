# petnica-summer-2018
Collection of tasks and projects written at Petnica Summer Course
